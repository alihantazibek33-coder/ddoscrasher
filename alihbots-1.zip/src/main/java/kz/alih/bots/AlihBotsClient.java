package kz.alih.bots;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;

import org.geysermc.mcprotocollib.network.Session;
import org.geysermc.mcprotocollib.network.event.session.SessionAdapter;
import org.geysermc.mcprotocollib.network.packet.Packet;
import org.geysermc.mcprotocollib.network.tcp.TcpClientSession;
import org.geysermc.mcprotocollib.protocol.MinecraftProtocol;
import org.geysermc.mcprotocollib.protocol.packet.ingame.clientbound.ClientboundLoginPacket;
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.ServerboundChatPacket;

import java.time.Instant;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Alih Bots - бір файлда бәрі: мод инициализаторы, меню (GUI) және бот-менеджер.
 * Чатқа ".alih go" жазсаң (серверге кетпейді), меню ашылады.
 * Бот саны мен атын, хабарлама жазу-жазбауын таңдап, "Ботты кіргізу" басасың.
 * Әр бот серверге кіреді де, 2 секунд сайын бір рет хабарлама жазып отырады (тоқтамай).
 */
public class AlihBotsClient implements ClientModInitializer {
    private static boolean openMenu = false;

    @Override
    public void onInitializeClient() {
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> {
            if (msg.trim().equalsIgnoreCase(".alih go")) {
                openMenu = true;
                return false; // серверге жібермей, тоқтатамыз
            }
            return true;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openMenu && client.currentScreen == null) {
                openMenu = false;
                client.setScreen(new BotScreen());
            }
        });
    }

    // ==================== GUI МЕНЮ ====================
    static class BotScreen extends Screen {
        private TextFieldWidget nameField, msgField, countField;
        private boolean sendChat = false;
        private String status = "";

        BotScreen() { super(Text.literal("Alih Bots")); }

        @Override
        protected void init() {
            int cx = width / 2;

            nameField = new TextFieldWidget(textRenderer, cx - 100, 40, 200, 20, Text.literal("Бот аты"));
            nameField.setMaxLength(11); // 11 + "-" + 4 = 16 (Minecraft ник лимиті)
            nameField.setPlaceholder(Text.literal("Негізгі ат (мыс: koch_bratan)"));
            addDrawableChild(nameField);

            countField = new TextFieldWidget(textRenderer, cx - 100, 70, 200, 20, Text.literal("Бот саны"));
            countField.setMaxLength(4);
            countField.setPlaceholder(Text.literal("Неше бот кіргізу керек? (мыс: 10)"));
            addDrawableChild(countField);

            ButtonWidget toggleBtn = ButtonWidget.builder(Text.literal("Чатқа жазу: ӨШІРУЛІ"), b -> {
                sendChat = !sendChat;
                b.setMessage(Text.literal("Чатқа жазу: " + (sendChat ? "ҚОСУЛЫ" : "ӨШІРУЛІ")));
                msgField.setVisible(sendChat);
            }).dimensions(cx - 100, 100, 200, 20).build();
            addDrawableChild(toggleBtn);

            msgField = new TextFieldWidget(textRenderer, cx - 100, 130, 200, 20, Text.literal("Текст"));
            msgField.setMaxLength(256);
            msgField.setPlaceholder(Text.literal("Бот не жазсын? (2 сек сайын қайталанады)"));
            msgField.setVisible(false);
            addDrawableChild(msgField);

            addDrawableChild(ButtonWidget.builder(Text.literal("Боттарды кіргізу"), b -> start())
                    .dimensions(cx - 100, 165, 200, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("Барлық ботты шығару (disconnect)"), b -> {
                BotManager.disconnectAll();
                status = "Барлық бот шығарылды";
            }).dimensions(cx - 100, 195, 200, 20).build());
        }

        private void start() {
            String base = nameField.getText().trim();
            if (base.isEmpty()) { status = "Атын жаз!"; return; }

            int count;
            try {
                count = Integer.parseInt(countField.getText().trim());
            } catch (Exception e) {
                count = 1;
            }
            if (count < 1) count = 1;
            if (count > 200) count = 200; // сервер/JVM қорғау үшін шектеу

            ServerInfo si = MinecraftClient.getInstance().getCurrentServerEntry();
            if (si == null) { status = "Серверге кіріп тұрғаныңды анықтай алмадым"; return; }

            String host = si.address;
            int port = 25565;
            if (host.contains(":")) {
                String[] p = host.split(":");
                host = p[0];
                try { port = Integer.parseInt(p[1]); } catch (Exception ignored) {}
            }

            String message = sendChat ? msgField.getText() : null;
            for (int i = 0; i < count; i++) {
                String botName = BotManager.randomName(base);
                BotManager.spawn(host, port, botName, message);
            }
            status = count + " бот жіберілді (" + base + "-xxxx)";
        }

        @Override
        public void render(DrawContext ctx, int mx, int my, float delta) {
            super.render(ctx, mx, my, delta);
            ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFFFFFF);
            ctx.drawCenteredTextWithShadow(textRenderer, status, width / 2, 225, 0xAAAAAA);
        }
    }

    // ==================== БОТ МЕНЕДЖЕРІ ====================
    static class BotManager {
        private static final ScheduledExecutorService EXEC = Executors.newScheduledThreadPool(4);
        private static final String CHARS = "abcdefghijklmnopqrstuvwxyz0123456789";
        private static final List<Session> SESSIONS = new ArrayList<>();

        /** koch_bratan -> koch_bratan-a7k2 */
        static String randomName(String base) {
            Random r = new Random();
            StringBuilder sb = new StringBuilder(base).append('-');
            for (int i = 0; i < 4; i++) sb.append(CHARS.charAt(r.nextInt(CHARS.length())));
            return sb.toString();
        }

        static void spawn(String host, int port, String name, String message) {
            MinecraftProtocol protocol = new MinecraftProtocol(name); // offline (cracked) режим
            Session session = new TcpClientSession(host, port, protocol);

            session.addListener(new SessionAdapter() {
                @Override
                public void packetReceived(Session s, Packet packet) {
                    if (packet instanceof ClientboundLoginPacket) {
                        synchronized (SESSIONS) { SESSIONS.add(s); }
                        if (message != null && !message.isBlank()) {
                            // кіріп болған соң 2 секундтан бастап, әрі қарай 2 сек сайын қайталап жазады
                            EXEC.scheduleAtFixedRate(() -> {
                                if (s.isConnected()) {
                                    s.send(new ServerboundChatPacket(
                                            message, Instant.now(), 0L, null, 0, new BitSet()));
                                }
                            }, 2, 2, TimeUnit.SECONDS);
                        }
                    }
                }

                @Override
                public void disconnected(org.geysermc.mcprotocollib.network.event.session.DisconnectedEvent event) {
                    synchronized (SESSIONS) { SESSIONS.remove(event.getSession()); }
                }
            });

            session.connect();
        }

        static void disconnectAll() {
            synchronized (SESSIONS) {
                for (Session s : SESSIONS) s.disconnect("alih disconnect");
                SESSIONS.clear();
            }
        }
    }
}
